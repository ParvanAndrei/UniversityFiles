#include <iostream>

int main(){
	std::cout<<"saying hello"<<std::endl;
}
