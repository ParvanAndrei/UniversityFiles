
void bubblesort(int *arr, int N)
{
//bubblesort
        int i,j;
//	int k;
        for (i=0; i< N-1; i++){
                for (j = 0; j < N - i - 1; j++){
                        if ( arr[j] > arr[j+1]){
                                int aux = arr[j];
                                arr[j] = arr[j+1];
                                arr[j+1] = aux;
                        }
                }
        }
//      for (k=0; k<N;k++)
//              std::cout<<arr[k] << " ";
//      std::cout<<std::endl;
}

