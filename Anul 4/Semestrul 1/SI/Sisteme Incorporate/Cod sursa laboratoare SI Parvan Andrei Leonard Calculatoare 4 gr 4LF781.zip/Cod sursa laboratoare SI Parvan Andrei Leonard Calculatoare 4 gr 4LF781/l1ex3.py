
n = input("Introduce a number:")

if  n.isdigit() :
	n = int(n)
	index = n
	array = []
	if n < 100 and n >0:
		i = 0
		while i != len(str(index)):
			x = n % 10
			n =int( n / 10)
			array.append(x)
			i = i +1
		print(array[::-1])
	else:
		print("number is not good")
elif n.startswith('-'):
	intermediar = n[1:]
	if intermediar.isdigit():
		intermediar = int(intermediar)
		index = intermediar
		array = []
		if intermediar < 100:
			i =0
			while i != len (str(index)):
				x = intermediar % 10
				intermediar = int(intermediar/10)
				array.append(x)
				i = i +1
			print("-",array[1::-1])
		else:
			print("number is not good")
	else:
		print(n, "is not a number")
else:
	print(n, "is not a number")
