//bubblesort
void bubblesort (int*, int);
//quicksort
void quicksort(int*, int, int);

void bitonicSort(int, int, int *);
