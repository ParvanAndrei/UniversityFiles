def mergeSort(sir1, sir2):
	i = 0
	j = 0
	final_sir = []
	len_sir1 = len(sir1)
	len_sir2 = len(sir2)
	while i < len_sir1 and j < len_sir2:
		if sir1[i] < sir2[j]:
			final_sir.append(sir1[i])
			i= i + 1
		else:
			final_sir.append(sir2[j])
			j = j + 1
	while i < len_sir1:
		final_sir.append(sir1[i])
		i = i + 1
	while j < len_sir2:
		final_sir.append(sir2[j])
		j = j + 1
	return final_sir


sir1 = [1,4,6]
sir2 = [2,3,5]
sir_rezultat = mergeSort(sir1,sir2)
print(sir_rezultat)
