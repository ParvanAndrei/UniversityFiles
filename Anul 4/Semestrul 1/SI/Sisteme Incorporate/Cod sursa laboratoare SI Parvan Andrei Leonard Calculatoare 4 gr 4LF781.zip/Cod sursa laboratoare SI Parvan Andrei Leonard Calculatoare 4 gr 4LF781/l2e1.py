getText = input("Introduce something:")

split = getText.split(" ")

max_len = -1
for element in split:
	if len(element) > max_len:
		max_len = len(element)
		longest = element

i = 0
f_line = ""
while i < len(longest):
	f_line = f_line + "*"
	i = i + 1
f_line = f_line + "**"
result = ""
print(f_line)
for i in range(0, len(split)):
	if len(split[i]) <= len(longest):
		result = result + "*"
		result = result + split[i]
		#print (len(result), len(longest))
		while len(result) <= len(longest):
			result = result + " "
		result = result + "*"
		print (result)
		result =""
print(f_line)
