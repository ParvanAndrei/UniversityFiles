#include "constante.h"
#include <iostream>
#include <ctime>

int * genereaza(int N)
{

	int *arr = new int[N];

//	srand((unsigned)time(NULL));

	for (int i= 0; i < N; i++)
	{
		arr[i] = rand();
	}
	return arr;
}


void sorteaza(int *arr, int N)
{
//bubblesort
	int i,j,k;
	for (i=0; i< N-1; i++){
		for (j = 0; j < N - i - 1; j++){
			if ( arr[j] > arr[j+1]){
				int aux = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = aux;
			}
		}
	}
//	for (k=0; k<N;k++)
//		std::cout<<arr[k] << " ";
//	std::cout<<std::endl;
}

void sorteaza2(int sir[], int st, int dr)
{
//quicksort
	if (st < dr)
	{
		int m = (st + dr) / 2;
		int aux = sir[st];
		sir[st] = sir[m];
		sir[m] = aux;
		int i = st, j = dr, d = 0;
		while (i < j)
		{
			if (sir[i] >= sir[j])
			{
				aux = sir[i];
				sir[i] = sir[j];
				sir[j] = aux;
				d = 1- d;
			}
			i = i + d;
			j -= 1 - d;
		}
		sorteaza2(sir, st, i-1);
		sorteaza2(sir, i+1, dr);
	}
}

int * contopire(int sir1[], int sir2[])
{
	int i, j, count = 0;
	int final_N = 2 * N;
	int *final_sir = new int [final_N];
	int len_sir1 = N;
	int len_sir2 = N;
	while (i < len_sir1 && j < len_sir2)
	{
		if (sir1[i] < sir2[j])
		{
		final_sir[count] = sir1[i];
		count = count + 1;
		i = i + 1;
		}
		else 
		{
		final_sir[count] = sir2[j];
		count = count + 1;
		j = j + 1;
		}
	}
	while ( i < len_sir1) 
	{
	final_sir[count] = sir1[i];
	count = count + 1;
	i = i + 1;
	}
	while ( j < len_sir2)
	{
	final_sir[count] = sir2[j];
	count = count + 1;
	j = j + 1;
 	}
	return final_sir;
}

int main ()
{
//	int N = 5;
	int *sir1, *sir2;

//	std::cout<<"Sir1:"<< std::endl;
	sir1 = genereaza(N);
//	std::cout<<"afisare cu for"<<std::endl;
//	for (int i =0; i < N; i++)
//	{
//	 std::cout<<sir1[i]<<std::endl;
//	}
//	std::cout<< "Sir2:" << std::endl;
	sir2 = genereaza(N);
//	std::cout<<"afisare cu for"<<std::endl;
//	for (int j = 0; j<N; j++)
//	{
//	std::cout<<sir2[j]<<std::endl;
//	}
//	std::cout<<std::endl;

//	std::cout<< "Sortare sir1:" << std::endl;
	sorteaza(sir1,N);
//	std::cout<< "Sortare sir2:" << std::endl;
	sorteaza2(sir2,0,N-1);
//	for (int i = 0; i < N; i++)
//	{
//		std::cout<<sir2[i]<<std::endl;
//	}

//	std::cout<< "Contopirea:" << std:: endl;
	int *rezultat = contopire(sir1, sir2);
//	for (int k = 0; k< 2 * N; k++)
//	{
//	std::cout<<rezultat[k]<<std::endl;
//	}
	return 0;
}
