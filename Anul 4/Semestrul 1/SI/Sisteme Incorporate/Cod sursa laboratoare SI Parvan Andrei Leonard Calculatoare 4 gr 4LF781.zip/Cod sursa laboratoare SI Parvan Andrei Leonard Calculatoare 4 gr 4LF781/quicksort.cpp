
void quicksort(int sir[], int st, int dr)
{
//quicksort
        if (st < dr)
        {
                int m = (st + dr) / 2;
                int aux = sir[st];
                sir[st] = sir[m];
                sir[m] = aux;
                int i = st, j = dr, d = 0;
                while (i < j)
                {
                        if (sir[i] >= sir[j])
                        {
                                aux = sir[i];
                                sir[i] = sir[j];
                                sir[j] = aux;
                                d = 1- d;
                        }
                        i = i + d;
                        j -= 1 - d;
                }
                quicksort(sir, st, i-1);
                quicksort(sir, i+1, dr);
        }
}

