#ifndef CONSTANTE_H
#define CONSTANTE_H
const int N = 16777216;
#endif
//pentru laboratorul3 exercitiul 2 E N este de 30000
// N era 16777216
