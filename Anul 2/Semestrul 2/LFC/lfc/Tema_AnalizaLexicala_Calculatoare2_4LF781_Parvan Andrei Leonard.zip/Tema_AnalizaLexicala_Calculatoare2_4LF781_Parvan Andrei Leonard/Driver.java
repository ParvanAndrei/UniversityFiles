import java.io.*;

public class Driver{
    public static void main(String[] args) throws Exception{
        File f = new File ("in.txt");
        FileInputStream fisier = new FileInputStream (f);

        Yylex scanner = new Yylex(fisier);
        int index = 0;
        do {
            Cauta car = scanner.next_token();
            if (car != null){
                int Trueline;
                Trueline = car.getlinie() +1;
                System.out.print("Am gasit myFunction la linia " + Trueline + ".\n");
                index++;
            } 

            if (car == null) {
                System.out.println("Au fost " +index+" apeluri ale functiei.");
                break;
            }
        } while (true);
    }
}