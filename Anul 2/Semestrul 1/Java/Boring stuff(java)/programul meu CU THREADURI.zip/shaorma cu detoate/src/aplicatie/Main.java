package aplicatie;

public class Main {
	public static void main(String args[])
	{
		ViewMain v = new ViewMain();
	}
}
